//
//
// prism.js
//
// Initialises the prism code highlighting plugin

import Prism from 'prismjs';

Prism.highlightAll();
